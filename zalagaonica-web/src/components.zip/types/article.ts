// types/article.ts - Prošireni tipovi

export interface Article {
  id: string;
  name: string;
  stock: number;
  unitOfMeasure: string;
  retailPrice: number;
  taxRate: number;
  supplierName: string;
  group?: string;
  status: 'available' | 'sold';
  saleInfo?: {
    salePrice: number;
    saleDate: string;
    customerName: string;
    customerId?: string;
  };
  warehouse?: 'main' | 'pledge'; // optional ili obavezno, prema potrebi
}


// types/sale.ts ili u article.ts ako preferiraš

export interface SaleData {
  id?: string;
  articleId: string;
  quantity: number;
  pricePerUnit: number;
  totalPrice: number;
  salePrice: number;
  saleDate: string;
  customerName: string;
  customerId?: string;
}


export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
}