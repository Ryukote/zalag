export interface CashRegisterTransaction {
  id: number;
  date: string; // Datum transakcije
  description: string; // Opis transakcije
  amount: number; // Iznos
  type: 'Uplata' | 'Isplata'; // Tip transakcije (Uplata/Isplata)
  note?: string; // Bilješke
}