export interface UnitOfMeasure {
  id: string;
  name: string;
  abbreviation: string;
  description?: string;
}
