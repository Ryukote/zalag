export interface Employee {
  id: string;
  name: string;
}

export interface Vacation {
  id: string;
  employeeId: string;
  employeeName?: string;
  startDate: string;
  endDate: string;
  status: 'odobreno' | 'na čekanju' | 'odbijeno';
  type: 'godišnji odmor' | 'bolovanje' | 'plaćeni dopust';
}

export interface Payroll {
  id: string;
  employeeId: string;
  employeeName?: string;
  month: string; // npr. "09/2025"
  baseSalary: number;
  bonus: number;
  deductions: number; // Odbici (npr. za pozajmicu)
  totalPaid: number;
}

export interface Loan {
    id: string;
    employeeId: string;
    employeeName?: string;
    date: string;
    amount: number;
    description: string;
    status: 'aktivna' | 'otplaćena';
}
