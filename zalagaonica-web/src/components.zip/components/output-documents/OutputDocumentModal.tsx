import React, { Fragment, useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { OutputDocument } from '../../types/outputDocument';
import { OutputDocumentDetailForm } from './OutputDocumentDetailForm';

interface OutputDocumentModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (document: OutputDocument) => void;
    initialData: OutputDocument | null;
}

const defaultDocument: OutputDocument = {
    id: '',
    type: 'individual',
    documentDate: new Date().toISOString().split('T')[0],
    customerName: '',
    totalValue: 0,
    status: 'draft',
    note: '',
    year: new Date().getFullYear(),
    warehouseName: 'Glavno Skladište',
    documentNumber: '',
    clientName: '',
    documentType: '',
    taxAmount: 0,
    totalWithTax: 0,
    operator: '',
    isPosted: false,
    paymentType: 'cash',
    isPaid: false,
    currency: '',
    items: [],
    totalRetailPrice: 0,
    totalTaxAmount: 0,
    totalWithoutTax: 0,
};

export const OutputDocumentModal: React.FC<OutputDocumentModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
    const [formData, setFormData] = useState<OutputDocument>(defaultDocument);

    useEffect(() => {
        setFormData(initialData || defaultDocument);
    }, [initialData, isOpen]);

    const handleSave = (data: OutputDocument) => {
        onSave(data);
    };

    return (
        <Transition.Root show={isOpen} as={Fragment}>
            <Dialog as="div" className="relative z-10" onClose={onClose}>
                <Transition.Child
                    as={Fragment}
                    enter="ease-out duration-300"
                    enterFrom="opacity-0"
                    enterTo="opacity-100"
                    leave="ease-in duration-200"
                    leaveFrom="opacity-100"
                    leaveTo="opacity-0"
                >
                    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
                </Transition.Child>

                <div className="fixed inset-0 z-10 overflow-y-auto">
                    <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                        <Transition.Child
                            as={Fragment}
                            enter="ease-out duration-300"
                            enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                            enterTo="opacity-100 translate-y-0 sm:scale-100"
                            leave="ease-in duration-200"
                            leaveFrom="opacity-100 translate-y-0 sm:scale-100"
                            leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        >
                            <Dialog.Panel className="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-3xl sm:p-6">
                                <div className="absolute right-0 top-0 hidden pr-4 pt-4 sm:block">
                                    <button
                                        type="button"
                                        className="rounded-md bg-white text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                        onClick={onClose}
                                    >
                                        <span className="sr-only">Zatvori</span>
                                        <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true">
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                </div>
                                <div>
                                    <div className="text-center">
                                        <Dialog.Title as="h3" className="text-xl font-semibold leading-6 text-gray-900">
                                            {initialData ? 'Uredi Izlazni Dokument' : 'Novi Izlazni Dokument'}
                                        </Dialog.Title>
                                    </div>
                                    <div className="mt-5">
                                        <OutputDocumentDetailForm
                                            document={formData}
                                            onSave={handleSave}
                                            onCancel={onClose}
                                        />
                                    </div>
                                </div>
                            </Dialog.Panel>
                        </Transition.Child>
                    </div>
                </div>
            </Dialog>
        </Transition.Root>
    );
};