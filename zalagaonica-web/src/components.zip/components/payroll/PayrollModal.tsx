import React, { Fragment, useState, useEffect } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Payroll, Employee } from '../../types/HR';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (payroll: Payroll) => void;
  initialData: Payroll | null;
  employees: Employee[];
}

const defaultData: Omit<Payroll, 'id' | 'employeeName' | 'totalPaid'> = { 
    employeeId: '', 
    month: `${(new Date().getMonth() + 1).toString().padStart(2, '0')}/${new Date().getFullYear()}`, 
    baseSalary: 0, 
    bonus: 0, 
    deductions: 0 
};

export const PayrollModal: React.FC<Props> = ({ isOpen, onClose, onSave, initialData, employees }) => {
  const [formData, setFormData] = useState(defaultData);

  useEffect(() => {
    const dataToSet = initialData ? { ...initialData } : { ...defaultData, employeeId: employees[0]?.id || '' };
    delete (dataToSet as Partial<Payroll>).employeeName;
    delete (dataToSet as Partial<Payroll>).totalPaid;
    setFormData(dataToSet);
  }, [initialData, isOpen, employees]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'number' ? parseFloat(value) || 0 : value }));
  };
  
  const handleSave = () => {
    if (!formData.employeeId) {
        alert("Molimo odaberite zaposlenika.");
        return;
    }
    const totalPaid = formData.baseSalary + formData.bonus - formData.deductions;
    const employeeName = employees.find(e => e.id === formData.employeeId)?.name;
    const finalData: Payroll = {
        id: initialData?.id || crypto.randomUUID(),
        employeeName: employeeName,
        totalPaid: totalPaid,
        ...formData
    };
    onSave(finalData);
  }

  return (
    <Transition.Root show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-10" onClose={onClose}>
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75" />
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <Dialog.Panel className="relative w-full max-w-lg rounded-lg bg-white p-6 shadow-xl">
              <Dialog.Title as="h3" className="text-xl font-semibold">
                {initialData ? 'Uredi obračun plaće' : 'Novi obračun plaće'}
              </Dialog.Title>
              
              <div className="mt-6 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
                <div className="sm:col-span-2">
                  <label htmlFor="employeeId" className="block text-sm font-medium">Zaposlenik</label>
                   <select name="employeeId" id="employeeId" value={formData.employeeId} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="" disabled>Odaberite zaposlenika</option>
                      {employees.map(emp => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="month" className="block text-sm font-medium">Mjesec (MM/GGGG)</label>
                  <input type="text" name="month" id="month" value={formData.month} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"/>
                </div>
                 <div>
                  <label htmlFor="baseSalary" className="block text-sm font-medium">Osnovica (€)</label>
                  <input type="number" name="baseSalary" id="baseSalary" value={formData.baseSalary} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"/>
                </div>
                 <div>
                  <label htmlFor="bonus" className="block text-sm font-medium">Bonus (€)</label>
                  <input type="number" name="bonus" id="bonus" value={formData.bonus} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"/>
                </div>
                 <div>
                  <label htmlFor="deductions" className="block text-sm font-medium">Odbici (€)</label>
                  <input type="number" name="deductions" id="deductions" value={formData.deductions} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"/>
                </div>
              </div>

              <div className="mt-8 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="rounded-md bg-white px-4 py-2 text-sm font-semibold ring-1 ring-inset ring-gray-300 hover:bg-gray-50">Odustani</button>
                <button type="button" onClick={handleSave} className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700">Spremi</button>
              </div>
            </Dialog.Panel>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};

