import React, { Fragment, useState, useEffect } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Client } from '../../types/client';

interface ClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: Client) => void;
  initialData: Client | null;
}

const defaultClient: Client = { id: 0, name: '', city: '', address: '', taxId: '', email: '', iban: '', type: 'legal', status: 'active', createdAt: '', updatedAt: '' };

export const ClientModal: React.FC<ClientModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [formData, setFormData] = useState<Client>(defaultClient);

  useEffect(() => {
    setFormData(initialData || defaultClient);
  }, [initialData, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSave = () => onSave(formData);

  return (
    <Transition.Root show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-10" onClose={onClose}>
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <Dialog.Panel className="relative w-full max-w-2xl rounded-lg bg-white p-6 shadow-xl">
              <Dialog.Title as="h3" className="text-xl font-semibold leading-6 text-gray-900">
                {initialData ? 'Uređivanje komitenta' : 'Novi komitent'}
              </Dialog.Title>
              
              <div className="mt-6 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium leading-6 text-gray-900">Naziv</label>
                  {/* << Dodan px-3 za razmak */}
                  <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className="mt-1 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"/>
                </div>
                <div>
                  <label htmlFor="taxId" className="block text-sm font-medium leading-6 text-gray-900">OIB</label>
                  {/* << Dodan px-3 za razmak */}
                  <input type="text" name="taxId" id="taxId" value={formData.taxId} onChange={handleChange} className="mt-1 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"/>
                </div>
                <div>
                  <label htmlFor="address" className="block text-sm font-medium leading-6 text-gray-900">Adresa</label>
                  {/* << Dodan px-3 za razmak */}
                  <input type="text" name="address" id="address" value={formData.address} onChange={handleChange} className="mt-1 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"/>
                </div>
                <div>
                  <label htmlFor="city" className="block text-sm font-medium leading-6 text-gray-900">Mjesto</label>
                  {/* << Dodan px-3 za razmak */}
                  <input type="text" name="city" id="city" value={formData.city} onChange={handleChange} className="mt-1 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"/>
                </div>
                 <div>
                  <label htmlFor="email" className="block text-sm font-medium leading-6 text-gray-900">Email</label>
                  {/* << Dodan px-3 za razmak */}
                  <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} className="mt-1 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"/>
                </div>
                <div>
                  <label htmlFor="iban" className="block text-sm font-medium leading-6 text-gray-900">IBAN</label>
                  {/* << Dodan px-3 za razmak */}
                  <input type="text" name="iban" id="iban" value={formData.iban} onChange={handleChange} className="mt-1 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"/>
                </div>
              </div>

              <div className="mt-8 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="rounded-md bg-white px-4 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50">Odustani</button>
                <button type="button" onClick={handleSave} className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700">Spremi</button>
              </div>
            </Dialog.Panel>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};