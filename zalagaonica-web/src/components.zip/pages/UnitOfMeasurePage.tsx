import React, { useState, useEffect, useMemo } from 'react';
import AppLayout from '../components/layout/AppLayout';
import Header from '../components/layout/Header';
import { Pagination } from '../components/ui/Pagination';
import { PlusIcon } from '@heroicons/react/24/outline';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { UnitOfMeasureModal } from '../components/units-of-measure/UnitOfMeasureModal';
import { UnitOfMeasureTable } from '../components/units-of-measure/UnitOfMeasureTable';
import { UnitOfMeasure } from '../types/unitsOfMeasure';

// Mock podaci za jedinice mjere
const MOCK_DATA: UnitOfMeasure[] = [
    { id: '1', name: 'Komad', abbreviation: 'kom' },
    { id: '2', name: 'Kilogram', abbreviation: 'kg' },
    { id: '3', name: 'Litara', abbreviation: 'L' },
    { id: '4', name: 'Metar', abbreviation: 'm' },
    { id: '5', name: 'Set', abbreviation: 'set' },
    { id: '6', name: 'Par', abbreviation: 'par' },
    { id: '7', name: 'Kubični metar', abbreviation: 'm3' },
    { id: '8', name: 'Tona', abbreviation: 't' },
    { id: '9', name: 'Milimetar', abbreviation: 'mm' },
    { id: '10', name: 'Centimetar', abbreviation: 'cm' },
    { id: '11', name: 'Decimetar', abbreviation: 'dm' },
];

const ITEMS_PER_PAGE_OPTIONS = [5, 10, 20];

const UnitOfMeasurePage: React.FC = () => {
    const [units, setUnits] = useState<UnitOfMeasure[]>(MOCK_DATA);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [editingUnit, setEditingUnit] = useState<UnitOfMeasure | null>(null);
    const [unitToDelete, setUnitToDelete] = useState<string | null>(null);

    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(ITEMS_PER_PAGE_OPTIONS[0]);

    // Logika za paginaciju
    const paginatedUnits = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        return units.slice(startIndex, endIndex);
    }, [units, currentPage, itemsPerPage]);

    const handleOpenAddModal = () => {
        setEditingUnit(null);
        setIsModalOpen(true);
    };

    const handleOpenEditModal = (item: UnitOfMeasure) => {
        setEditingUnit(item);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingUnit(null);
    };

    const handleSaveUnit = (newUnit: UnitOfMeasure) => {
        if (editingUnit) {
            // Ažuriranje postojeće jedinice
            setUnits(units.map(u => u.id === newUnit.id ? newUnit : u));
        } else {
            // Dodavanje nove jedinice
            const newId = (Math.max(...units.map(u => parseInt(u.id))) + 1).toString();
            setUnits([...units, { ...newUnit, id: newId }]);
        }
        handleCloseModal();
    };

    const handleConfirmDelete = (id: string) => {
        setUnitToDelete(id);
        setIsConfirmOpen(true);
    };

    const handleDeleteUnit = () => {
        setUnits(units.filter(u => u.id !== unitToDelete));
        setIsConfirmOpen(false);
        setUnitToDelete(null);
    };

    return (
        <AppLayout>
            <Header title="Jedinice Mjere" showBackButton={true} />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
                <div className="sm:flex sm:items-center">
                    <div className="sm:flex-auto">
                        <h1 className="text-xl font-semibold text-gray-900">Jedinice Mjere</h1>
                        <p className="mt-2 text-sm text-gray-700">Popis svih jedinica mjere.</p>
                    </div>
                    <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
                        <button
                            type="button"
                            onClick={handleOpenAddModal}
                            className="inline-flex items-center justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
                        >
                            <PlusIcon className="h-5 w-5 mr-2" />
                            Nova jedinica mjere
                        </button>
                    </div>
                </div>

                <div className="mt-8 flow-root">
                    <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                            <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                                <UnitOfMeasureTable 
                                    data={paginatedUnits} 
                                    onEdit={handleOpenEditModal} 
                                    onDelete={handleConfirmDelete}
                                />
                            </div>
                            <Pagination 
                                currentPage={currentPage}
                                totalCount={units.length}
                                itemsPerPage={itemsPerPage}
                                onPageChange={page => setCurrentPage(page)}
                                onItemsPerPageChange={setItemsPerPage}
                            />
                        </div>
                    </div>
                </div>
            </div>
            
            <UnitOfMeasureModal 
                isOpen={isModalOpen} 
                onClose={handleCloseModal} 
                onSave={handleSaveUnit} 
                initialData={editingUnit} 
            />
            <ConfirmDialog 
                isOpen={isConfirmOpen} 
                onClose={() => setIsConfirmOpen(false)} 
                onConfirm={handleDeleteUnit} 
                title="Potvrda brisanja" 
                message="Jeste li sigurni da želite obrisati ovu jedinicu mjere? Ova radnja se ne može poništiti." 
            />
        </AppLayout>
    );
};

export default UnitOfMeasurePage;