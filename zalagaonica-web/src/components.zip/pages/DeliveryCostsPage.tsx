import React, { useState } from 'react';
import { DeliveryCostModal } from '../components/delivery-cost/DeliveryCostModal';
import { DeliveryCostsTable } from '../components/delivery-cost/DeliveryCostsTable';
import { DeliveryCost } from '../types/DeliveryCost';

const mockCosts: DeliveryCost[] = [
    { id: '1', date: '2025-09-18', courier: 'GLS', trackingNumber: '123456789', description: 'Slanje paketa za Split', cost: 7.50 },
    { id: '2', date: '2025-09-17', courier: 'DPD', trackingNumber: '987654321', description: 'Otkupnina za Osijek', cost: 9.00 },
];

const DeliveryCostsPage: React.FC = () => {
  const [costs, setCosts] = useState<DeliveryCost[]>(mockCosts);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCost, setEditingCost] = useState<DeliveryCost | null>(null);

  const handleEdit = (cost: DeliveryCost) => {
      setEditingCost(cost);
      setIsModalOpen(true);
  }

  const handleSave = (cost: DeliveryCost) => {
      // Logika za spremanje
      setIsModalOpen(false);
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Troškovi dostave paketa</h1>
        <button onClick={() => { setEditingCost(null); setIsModalOpen(true); }} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-sm">
          Dodaj novi trošak
        </button>
      </div>

      <DeliveryCostsTable data={costs} onEdit={handleEdit} onDelete={() => {}}/>

      {isModalOpen && (
        <DeliveryCostModal 
            isOpen={isModalOpen}
            initialData={editingCost}
            onClose={() => setIsModalOpen(false)}
            onSave={handleSave}
        />
      )}
    </div>
  );
};

export default DeliveryCostsPage;
