import React, { useState } from 'react';
import AppLayout from '../components/layout/AppLayout';
import Header from '../components/layout/Header';
import { Pagination } from '../components/ui/Pagination';
import { PlusIcon, ArrowDownTrayIcon } from '@heroicons/react/24/outline';
import { ArticleModal } from '../components/articles/ArticleModal';
import { ArticleTable } from '../components/articles/ArticleTable';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { SaleModal } from '../components/sale/SaleModal';
import { useInventory, SaleData } from '../context/InventoryContext';
import { Article } from '../types/article';

export const ArticleListPage: React.FC = () => {
  const { articles, addArticle, updateArticle, sale } = useInventory();

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [articleToSave, setArticleToSave] = useState<Article | null>(null);

  const [isSaleModalOpen, setIsSaleModalOpen] = useState(false);
  const [sellingArticle, setSellingArticle] = useState<Article | null>(null);
  const [isSaleConfirmOpen, setIsSaleConfirmOpen] = useState(false);
  const [saleToConfirm, setSaleToConfirm] = useState<{ article: Article; saleData: SaleData } | null>(null);

  const handleSaleArticle = (saleDataFromModal: SaleData) => {
    if (!sellingArticle) return;

    const success = sale(sellingArticle.id, saleDataFromModal.quantity, saleDataFromModal);

    if (success) {
      setIsSaleModalOpen(false);
      setSaleToConfirm({ article: sellingArticle, saleData: saleDataFromModal });
      setIsSaleConfirmOpen(true);
    }
  };

  const currentItems = articles.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  
  const handleItemsPerPageChange = (value: number) => {
    setItemsPerPage(value);
    setCurrentPage(1);
  };

  const handleOpenAddModal = () => {
    setEditingArticle(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (article: Article) => {
    setEditingArticle(article);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingArticle(null);
  };

  const handleSaveArticle = (articleData: Article) => {
    setArticleToSave(articleData);
    setIsModalOpen(false);
    setIsConfirmOpen(true);
  };

  const handleConfirmSave = () => {
    if (!articleToSave) return;

    if (editingArticle) {
      updateArticle(articleToSave);
    } else {
      const newArticle = { ...articleToSave, id: String(Date.now()), status: 'available' as const };
      addArticle(newArticle);
    }

    setIsConfirmOpen(false);
    setArticleToSave(null);
    setEditingArticle(null);
  };

  const handleOpenSaleModal = (article: Article) => {
    setSellingArticle(article);
    setIsSaleModalOpen(true);
  };

  const handleCloseSaleModal = () => {
    setIsSaleModalOpen(false);
    setSellingArticle(null);
  };

  const handleConfirmSale = () => {
    setIsSaleConfirmOpen(false);
    setSaleToConfirm(null);
    setSellingArticle(null);
  };

  const handleCancelSale = () => {
    setIsSaleConfirmOpen(false);
    setSaleToConfirm(null);
  };

  return (
    <AppLayout>
      <div className="px-6 py-8 bg-gray-50 min-h-screen">
        <Header title="Artikli i cjenik" showBackButton={true} />
        <div className="mt-6 md:flex md:items-center md:justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span>Ukupno artikala: {articles.length}</span>
              <span className="text-green-600">Dostupno: {articles.filter((a) => a.status === 'available').length}</span>
              <span className="text-red-600">Prodano: {articles.filter((a) => a.status === 'sold').length}</span>
            </div>
          </div>
          <div className="mt-4 flex md:mt-0 md:ml-4">
            <button 
              type="button" 
              className="flex items-center justify-center rounded-md bg-white px-4 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
            >
              <ArrowDownTrayIcon className="h-5 w-5 mr-2 text-gray-500" />
              Izvoz
            </button>
            <button 
              type="button" 
              onClick={handleOpenAddModal} 
              className="ml-3 flex items-center justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
            >
              <PlusIcon className="h-5 w-5 mr-2" />
              Novi Artikl
            </button>
          </div>
        </div>

        <div className="mt-8 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                <ArticleTable
                  data={currentItems}
                  onEdit={handleOpenEditModal}
                  onSell={handleOpenSaleModal}
                />
              </div>
              <Pagination
                currentPage={currentPage}
                totalCount={articles.length}
                itemsPerPage={itemsPerPage}
                onPageChange={page => setCurrentPage(page)}
                onItemsPerPageChange={handleItemsPerPageChange}
              />
            </div>
          </div>
        </div>
      </div>

      <ArticleModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSaveArticle}
        initialData={editingArticle}
      />

      {sellingArticle && (
        <SaleModal
          isOpen={isSaleModalOpen}
          onClose={handleCloseSaleModal}
          onSale={handleSaleArticle}
          article={sellingArticle}
        />
      )}

      <ConfirmDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirmSave}
        title="Potvrda izmjena"
        message="Jeste li sigurni da želite spremiti promjene?"
      />

      <ConfirmDialog
        isOpen={isSaleConfirmOpen}
        onClose={handleCancelSale}
        onConfirm={handleConfirmSale}
        title="Potvrda prodaje"
        message={
          saleToConfirm
            ? `Jeste li sigurni da želite prodati "${saleToConfirm.article.name}" za ${new Intl.NumberFormat('hr-HR', { style: 'currency', currency: 'EUR' }).format(saleToConfirm.saleData.totalPrice)}?`
            : 'Jeste li sigurni da želite završiti prodaju?'
        }
      />
    </AppLayout>
  );
};