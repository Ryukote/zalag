import React, { useState, useMemo } from 'react';
import VehicleDetails from '../components/vehicles/VehicleDetails';
import { VehicleEventModal } from '../components/vehicles/VehicleEventModal';
import { VehicleModal } from '../components/vehicles/VehicleModal';
import { Vehicle, VehicleEvent } from '../types/VehicleEventType';

const mockVehicles: Vehicle[] = [
  { id: 'v1', make: 'Volkswagen', model: 'Golf 8', year: 2022, registrationPlate: 'ZG-1234-AB' },
  { id: 'v2', make: 'Opel', model: 'Corsa', year: 2021, registrationPlate: 'ST-5678-CD' },
  { id: 'v3', make: 'Mercedes', model: 'C-klasa', year: 2023, registrationPlate: 'RI-2023-EF' },
];

const mockEvents: VehicleEvent[] = [
    { id: 'e1', vehicleId: 'v1', date: '2025-09-15', type: 'Servis', description: 'Redovni servis - izmjena ulja i filtera', cost: 150 },
    { id: 'e2', vehicleId: 'v1', date: '2025-08-20', type: 'Registracija', description: 'Tehnički pregled i produljenje registracije', cost: 200, expiryDate: '2026-08-20' },
    { id: 'e3', vehicleId: 'v1', date: '2025-07-01', type: 'Kazna', description: 'Kazna za nepropisno parkiranje', cost: 50, status: 'plaćeno' },
    { id: 'e4', vehicleId: 'v2', date: '2025-09-01', type: 'Servis', description: 'Zamjena guma', cost: 250 },
    { id: 'e5', vehicleId: 'v2', date: '2025-05-10', type: 'Osiguranje', description: 'Godišnja polica AO', cost: 300, expiryDate: '2026-05-10' },
];

const VehiclesPage: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(mockVehicles);
  const [events, setEvents] = useState<VehicleEvent[]>(mockEvents);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(vehicles[0] || null);
  
  const [isVehicleModalOpen, setVehicleModalOpen] = useState(false);
  const [isEventModalOpen, setEventModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);

  const selectedVehicleEvents = useMemo(() => {
    return selectedVehicle ? events.filter(e => e.vehicleId === selectedVehicle.id) : [];
  }, [selectedVehicle, events]);

  const handleAddNewVehicle = () => {
    setEditingVehicle(null);
    setVehicleModalOpen(true);
  };

  const handleEditVehicle = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setVehicleModalOpen(true);
  }

  const handleSaveVehicle = (vehicle: Vehicle) => {
    // Logika za spremanje...
    setVehicleModalOpen(false);
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Evidencija vozila</h1>
        <button onClick={handleAddNewVehicle} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-sm">
          Dodaj novo vozilo
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Lista vozila */}
        <div className="lg:col-span-1 bg-white p-4 rounded-lg shadow h-fit">
          <h2 className="text-lg font-bold mb-4">Popis vozila</h2>
          <ul className="space-y-2">
            {vehicles.map(v => (
              <li key={v.id} onClick={() => setSelectedVehicle(v)} 
                  className={`p-3 rounded-md cursor-pointer transition-all ${selectedVehicle?.id === v.id ? 'bg-indigo-100 ring-2 ring-indigo-500' : 'hover:bg-gray-100'}`}>
                <p className="font-semibold">{v.make} {v.model}</p>
                <p className="text-sm text-gray-600">{v.registrationPlate}</p>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Detalji odabranog vozila */}
        <div className="lg:col-span-3">
          {selectedVehicle ? (
            <VehicleDetails 
              vehicle={selectedVehicle} 
              events={selectedVehicleEvents}
              onEditVehicle={handleEditVehicle}
              onAddEvent={() => setEventModalOpen(true)}
            />
          ) : (
            <div className="flex items-center justify-center h-full bg-white p-4 rounded-lg shadow">
              <p className="text-gray-500">Odaberite vozilo za prikaz detalja.</p>
            </div>
          )}
        </div>
      </div>

      {isVehicleModalOpen && (
        <VehicleModal 
            isOpen={isVehicleModalOpen}
            initialData={editingVehicle}
            onClose={() => setVehicleModalOpen(false)}
            onSave={handleSaveVehicle}
        />
      )}

      {isEventModalOpen && selectedVehicle && (
        <VehicleEventModal
            isOpen={isEventModalOpen}
            vehicleId={selectedVehicle.id}
            onClose={() => setEventModalOpen(false)}
            onSave={(event: any) => { /* logika za spremanje */ setEventModalOpen(false); }}
        />
      )}
    </div>
  );
};

export default VehiclesPage;
