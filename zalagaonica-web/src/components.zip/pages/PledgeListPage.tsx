import React, { useState } from 'react';
import { MagnifyingGlassIcon, PencilIcon, TrashIcon, EyeIcon } from '@heroicons/react/24/outline';
import Header from '../components/layout/Header';
import { useInventory } from '../context/InventoryContext';

const PledgeListPage: React.FC = () => {
  const { pledges, deletePledge, updatePledge } = useInventory();
  const [editing, setEditing] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'svi' | 'aktivan' | 'isplaćen' | 'istekao'>('svi');

  const filteredPledges = pledges
    .filter(p => statusFilter === 'svi' || (p.redeemed ? 'isplaćen' : 'aktivan') === statusFilter)
    .filter(p => p.clientName.toLowerCase().includes(searchTerm.toLowerCase()));

  const handleDelete = (id: string) => {
    if (confirm('Želite li obrisati ovaj zalog?')) deletePledge(id);
  };

  const handleEdit = (id: string) => {
    setEditing(id);
  };

  if (editing) {
    const pledge = pledges.find(p => p.id === editing);
    if (!pledge) return null;

    return (
      <div className="px-6 py-8 bg-gray-50 min-h-screen">
        <Header title={`Uređivanje zaloga: ${pledge.id}`} showBackButton={true} />
        <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Uredi podatke o zalogu</h2>
          <label className="block text-sm font-medium text-gray-700">Vrijednost zaloga (€)</label>
          <input
            type="number"
            value={pledge.pledgeValue}
            onChange={e => updatePledge({ ...pledge, pledgeValue: parseFloat(e.target.value) })}
            className="block w-full mt-1 rounded-md border-gray-300 shadow-sm"
          />
          <button
            onClick={() => setEditing(null)}
            className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
          >
            Spremi
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-6 py-8 bg-gray-50 min-h-screen">
      <Header title="Knjiga Zaloga" showBackButton={true} />

      <div className="mt-6 md:flex md:items-center md:justify-between">
        <div className="relative rounded-md shadow-sm">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="search"
            className="block w-full rounded-md border-0 py-2 pl-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-indigo-600 sm:text-sm"
            placeholder="Pretraži po imenu klijenta..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="mt-4 flex items-center md:mt-0 md:ml-4">
          <label htmlFor="status" className="block text-sm font-medium text-gray-700 mr-2">
            Status:
          </label>
          <select
            id="status"
            className="block w-full rounded-md border-0 py-2 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-indigo-600 sm:text-sm"
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as any)}
          >
            <option value="svi">Svi</option>
            <option value="aktivan">Aktivni</option>
            <option value="isplaćen">Isplaćeni</option>
            <option value="istekao">Istekli</option>
          </select>
        </div>
      </div>

      <div className="mt-8">
        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">#</th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Klijent</th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Vrijednost</th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Status</th>
                <th className="px-3 py-3.5 text-right text-sm font-semibold text-gray-900">Akcije</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {filteredPledges.map(p => (
                <tr key={p.id}>
                  <td className="px-3 py-2 text-sm font-medium text-gray-900">{p.id}</td>
                  <td className="px-3 py-2 text-sm text-gray-500">{p.clientName}</td>
                  <td className="px-3 py-2 text-sm text-gray-500">{p.pledgeValue.toFixed(2)} €</td>
                  <td className="px-3 py-2 text-sm">
                    {p.redeemed ? (
                      <span className="text-green-700 font-medium">Isplaćen</span>
                    ) : (
                      <span className="text-blue-700 font-medium">Aktivan</span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-right space-x-3">
                    <button onClick={() => handleEdit(p.id)} className="text-indigo-600 hover:text-indigo-900">
                      <PencilIcon className="h-5 w-5" />
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-800">
                      <TrashIcon className="h-5 w-5" />
                    </button>
                    <button className="text-gray-500 hover:text-gray-700">
                      <EyeIcon className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredPledges.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-3 py-4 text-center text-gray-500">
                    Nema pronađenih zaloga.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PledgeListPage;
