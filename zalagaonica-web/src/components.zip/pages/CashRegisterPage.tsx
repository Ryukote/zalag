import React, { useState, useEffect, useMemo } from 'react';
import AppLayout from '../components/layout/AppLayout';
import Header from '../components/layout/Header';
import { PlusIcon } from '@heroicons/react/24/outline';
import { Pagination } from '../components/ui/Pagination';
import { CashRegisterTable } from '../components/cash-register/CashRegisterTable';
import { CashRegisterModal } from '../components/cash-register/CashRegisterModal';
import { CashRegisterTransaction } from '../types/cashRegisterTransaction';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';

const MOCK_TRANSACTIONS: CashRegisterTransaction[] = [
    {
        id: 1,
        date: '2025-08-20',
        description: 'Dnevna blagajna - otvaranje',
        amount: 500.00,
        type: 'Uplata',
    },
    {
        id: 2,
        date: '2025-08-20',
        description: 'Isplata za troškove ureda',
        amount: -50.00,
        type: 'Isplata',
    },
    {
        id: 3,
        date: '2025-08-21',
        description: 'Uplata od prodaje robe',
        amount: 1250.75,
        type: 'Uplata',
    },
    {
        id: 4,
        date: '2025-08-21',
        description: 'Isplata dobavljaču',
        amount: -800.00,
        type: 'Isplata',
    },
    {
        id: 5,
        date: '2025-08-22',
        description: 'Dnevna blagajna - otvaranje',
        amount: 600.00,
        type: 'Uplata',
    },
    {
        id: 6,
        date: '2025-08-22',
        description: 'Isplata za gorivo',
        amount: -150.00,
        type: 'Isplata',
    },
    {
        id: 7,
        date: '2025-08-23',
        description: 'Uplata od prodaje usluga',
        amount: 350.50,
        type: 'Uplata',
    },
];

export const CashRegisterPage: React.FC = () => {
    const [transactions, setTransactions] = useState<CashRegisterTransaction[]>(MOCK_TRANSACTIONS);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [editingTransaction, setEditingTransaction] = useState<CashRegisterTransaction | null>(null);
    const [transactionToSave, setTransactionToSave] = useState<CashRegisterTransaction | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);

    const paginatedTransactions = useMemo(() => {
        const firstItemIndex = (currentPage - 1) * itemsPerPage;
        const lastItemIndex = firstItemIndex + itemsPerPage;
        return transactions.slice(firstItemIndex, lastItemIndex);
    }, [transactions, currentPage, itemsPerPage]);
    
    const handleOpenModal = () => {
        setEditingTransaction(null);
        setIsModalOpen(true);
    };

    const handleOpenEditModal = (transaction: CashRegisterTransaction) => {
        setEditingTransaction(transaction);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingTransaction(null);
        setTransactionToSave(null);
    };
    
    const handleSaveTransaction = (transaction: CashRegisterTransaction) => {
        setTransactionToSave(transaction);
        setIsConfirmOpen(true);
    };

    const handleConfirmSave = () => {
        if (!transactionToSave) return;
        
        setTransactions(prevTransactions => {
            if (prevTransactions.some(t => t.id === transactionToSave.id)) {
                return prevTransactions.map(t =>
                    t.id === transactionToSave.id ? transactionToSave : t
                );
            } else {
                return [...prevTransactions, transactionToSave];
            }
        });

        handleCloseModal();
        setIsConfirmOpen(false);
    };

    const handleItemsPerPageChange = (value: number) => {
        setItemsPerPage(value);
        setCurrentPage(1); // Reset to first page
    };

    return (
        <AppLayout>
            <div className="flex flex-col h-full p-8">
                <Header title="Blagajna" showBackButton={true} />
                
                <div className="flex justify-between items-center mt-6">
                    <h2 className="text-2xl font-semibold text-gray-800">Pregled transakcija</h2>
                    <button
                        type="button"
                        onClick={handleOpenModal}
                        className="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                    >
                        <PlusIcon className="h-5 w-5 mr-2" />
                        Novi unos
                    </button>
                </div>

                <div className="mt-8 flow-root flex-grow">
                    <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                            <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                                <CashRegisterTable data={paginatedTransactions} onEdit={handleOpenEditModal} />
                            </div>
                            <Pagination 
                                currentPage={currentPage}
                                totalCount={transactions.length}
                                itemsPerPage={itemsPerPage}
                                onPageChange={setCurrentPage}
                                onItemsPerPageChange={handleItemsPerPageChange}
                            />
                        </div>
                    </div>
                </div>
            </div>
            
            <CashRegisterModal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveTransaction}
                initialData={editingTransaction}
            />
            
            <ConfirmDialog
                isOpen={isConfirmOpen}
                onClose={() => setIsConfirmOpen(false)}
                onConfirm={handleConfirmSave}
                title="Potvrda spremanja"
                message="Jeste li sigurni da želite spremiti transakciju?"
            />
        </AppLayout>
    );
};
