import React, { useState, useEffect } from 'react';
import AppLayout from '../components/layout/AppLayout';
import Header from '../components/layout/Header';
import { Pagination } from '../components/ui/Pagination';
import { PlusIcon, ArrowDownTrayIcon } from '@heroicons/react/24/outline';
import { PriceListModal } from '../components/price-list/PriceListModal';
import { PriceListTable } from '../components/price-list/PriceListTable';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { PriceListItem } from '../types/priceListItem';

const MOCK_DATA: PriceListItem[] = [
    { id: 'C101', name: 'Artikl Cjenik A', stock: 150, unitOfMeasure: 'kom', retailPrice: 20.79, retailPriceWithTax: 25.99, taxRate: 25, supplierName: 'Dobavljač d.o.o.', group: 'A', taxTariffNumber: 'OP25' },
    { id: 'C102', name: 'Artikl Cjenik B (usluga)', stock: 0, unitOfMeasure: 'kom', retailPrice: 120.00, retailPriceWithTax: 150.00, taxRate: 25, supplierName: 'Dobavljač d.o.o.', group: 'B', taxTariffNumber: 'OP25' },
    { id: 'C103', name: 'Još jedna stavka', stock: 45, unitOfMeasure: 'kg', retailPrice: 11.06, retailPriceWithTax: 12.50, taxRate: 13, supplierName: 'Farma Produkt', group: 'A', taxTariffNumber: 'OP13' },
    { id: 'C104', name: 'Stavka C', stock: 200, unitOfMeasure: 'kom', retailPrice: 7.99, retailPriceWithTax: 9.99, taxRate: 25, supplierName: 'Veleprodaja ZG', group: 'C', taxTariffNumber: 'OP25' },
    { id: 'C105', name: 'Stavka D', stock: 12, unitOfMeasure: 'lit', retailPrice: 13.27, retailPriceWithTax: 15.00, taxRate: 13, supplierName: 'Farma Produkt', group: 'A', taxTariffNumber: 'OP13' },
    { id: 'C106', name: 'Stavka E', stock: 88, unitOfMeasure: 'kom', retailPrice: 39.60, retailPriceWithTax: 49.50, taxRate: 25, supplierName: 'Dobavljač d.o.o.', group: 'B', taxTariffNumber: 'OP25' },
    { id: 'C107', name: 'Stavka F', stock: 23, unitOfMeasure: 'kom', retailPrice: 159.99, retailPriceWithTax: 199.99, taxRate: 25, supplierName: 'Veleprodaja ZG', group: 'C', taxTariffNumber: 'OP25' },
    { id: 'C108', name: 'Stavka G', stock: 5, unitOfMeasure: 'kom', retailPrice: 71.20, retailPriceWithTax: 89.00, taxRate: 25, supplierName: 'Dobavljač d.o.o.', group: 'B', taxTariffNumber: 'OP25' },
];

export const PriceListPage: React.FC = () => {
    const [priceListItems, setPriceListItems] = useState<PriceListItem[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<PriceListItem | null>(null);
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [itemToSave, setItemToSave] = useState<PriceListItem | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);
    
    useEffect(() => {
        setPriceListItems(MOCK_DATA);
    }, []);

    const handleItemsPerPageChange = (value: number) => {
        setItemsPerPage(value);
        setCurrentPage(1);
    };

    const handleOpenAddModal = () => {
        setEditingItem(null);
        setIsModalOpen(true);
    };

    const handleOpenEditModal = (item: PriceListItem) => {
        setEditingItem(item);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleSaveItem = (itemData: PriceListItem) => {
        setItemToSave(itemData);
        setIsModalOpen(false);
        setIsConfirmOpen(true);
    };

    const handleConfirmSave = () => {
        if (!itemToSave) return;
        if (editingItem) {
            setPriceListItems(prev => prev.map(i => i.id === itemToSave.id ? itemToSave : i));
        } else {
            setPriceListItems(prev => [{...itemToSave, id: `C${Date.now()}`}, ...prev]);
        }
        setIsConfirmOpen(false);
        setItemToSave(null);
        setEditingItem(null);
    };

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = priceListItems.slice(indexOfFirstItem, indexOfLastItem);

    return (
        <AppLayout>
            <div className="px-6 py-8 bg-gray-50 min-h-screen">
                <Header title="Cjenik - Lager Lista" showBackButton={true} />

                <div className="mt-6 md:flex md:items-center md:justify-between">
                    <div className="flex-1 min-w-0">
                        {/* Ovdje će ići filteri specifični za cjenik */}
                    </div>
                    <div className="mt-4 flex-shrink-0 flex md:mt-0 md:ml-4">
                        <button
                          type="button"
                          className="flex items-center justify-center rounded-md bg-white px-4 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
                        >
                          <ArrowDownTrayIcon className="h-5 w-5 mr-2 text-gray-500" />
                          Izvoz
                        </button>
                        <button
                          type="button"
                          onClick={handleOpenAddModal}
                          className="ml-3 flex items-center justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
                        >
                          <PlusIcon className="h-5 w-5 mr-2" />
                          Nova Stavka
                        </button>
                    </div>
                </div>

                <div className="mt-8 flow-root">
                    <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                            <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                                <PriceListTable data={currentItems} onEdit={handleOpenEditModal} />
                            </div>
                            <Pagination 
                                currentPage={currentPage}
                                totalCount={priceListItems.length}
                                itemsPerPage={itemsPerPage}
                                onPageChange={page => setCurrentPage(page)}
                                onItemsPerPageChange={handleItemsPerPageChange}
                            />
                        </div>
                    </div>
                </div>
            </div>
            
            <PriceListModal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveItem}
                initialData={editingItem}
            />
            <ConfirmDialog
                isOpen={isConfirmOpen}
                onClose={() => setIsConfirmOpen(false)}
                onConfirm={handleConfirmSave}
                title="Potvrda izmjena"
                message="Jeste li sigurni da želite spremiti promjene?"
            />
        </AppLayout>
    );
};