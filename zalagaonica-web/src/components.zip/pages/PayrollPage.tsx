import React, { useState } from 'react';
import { PayrollModal } from '../components/payroll/PayrollModal';
import { PayrollTable } from '../components/payroll/PayrollTable';
import { Employee, Payroll, Loan } from '../types/HR';
import LoanModal from '../components/loans/LoanModal';
import LoansTable from '../components/loans/LoansTable';

// Mock podaci - u stvarnoj aplikaciji dolazili bi s backenda
const mockEmployees: Employee[] = [
    { id: 'emp1', name: 'Marko Markić' },
    { id: 'emp2', name: 'Ana Anić' },
];

const mockPayrolls: Payroll[] = [
    { id: 'pay1', employeeId: 'emp1', employeeName: 'Marko Markić', month: '08/2025', baseSalary: 1200, bonus: 150, deductions: 50, totalPaid: 1300 },
    { id: 'pay2', employeeId: 'emp2', employeeName: 'Ana Anić', month: '08/2025', baseSalary: 1100, bonus: 0, deductions: 0, totalPaid: 1100 },
];

const mockLoans: Loan[] = [
    { id: 'loan1', employeeId: 'emp1', employeeName: 'Marko Markić', date: '2025-07-15', amount: 500, description: 'Akontacija', status: 'aktivna' },
];

const PayrollPage: React.FC = () => {
  const [payrolls, setPayrolls] = useState<Payroll[]>(mockPayrolls);
  const [loans, setLoans] = useState<Loan[]>(mockLoans);
  const [activeTab, setActiveTab] = useState<'payroll' | 'loans'>('payroll');
  
  // Stanja za modale
  const [isPayrollModalOpen, setIsPayrollModalOpen] = useState(false);
  const [editingPayroll, setEditingPayroll] = useState<Payroll | null>(null);
  const [isLoanModalOpen, setIsLoanModalOpen] = useState(false);
  const [editingLoan, setEditingLoan] = useState<Loan | null>(null);

  // Funkcije za plaće
  const handleSavePayroll = (payroll: Payroll) => {
    if (editingPayroll) {
        setPayrolls(payrolls.map(p => p.id === payroll.id ? payroll : p));
    } else {
        setPayrolls([...payrolls, payroll]);
    }
    setIsPayrollModalOpen(false);
  };
  const handleEditPayroll = (payroll: Payroll) => {
    setEditingPayroll(payroll);
    setIsPayrollModalOpen(true);
  };
   const handleAddNewPayroll = () => {
    setEditingPayroll(null);
    setIsPayrollModalOpen(true);
  };
  const handleDeletePayroll = (id: string) => {
      setPayrolls(payrolls.filter(p => p.id !== id));
  }

  // Funkcije za pozajmice
  const handleSaveLoan = (loan: Loan) => {
    if (editingLoan) {
        setLoans(loans.map(l => l.id === loan.id ? loan : l));
    } else {
        setLoans([...loans, loan]);
    }
    setIsLoanModalOpen(false);
  };
  const handleEditLoan = (loan: Loan) => {
    setEditingLoan(loan);
    setIsLoanModalOpen(true);
  };
  const handleAddNewLoan = () => {
    setEditingLoan(null);
    setIsLoanModalOpen(true);
  };
  const handleDeleteLoan = (id: string) => {
      setLoans(loans.filter(l => l.id !== id));
  }

  return (
    <div className="p-6">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          <button onClick={() => setActiveTab('payroll')} className={`${activeTab === 'payroll' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
            Evidencija plaća
          </button>
          <button onClick={() => setActiveTab('loans')} className={`${activeTab === 'loans' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>
            Evidencija pozajmica
          </button>
        </nav>
      </div>
      <div className="mt-6">
        {activeTab === 'payroll' && (
          <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Obračuni plaća</h2>
                <button onClick={handleAddNewPayroll} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-sm">Novi obračun</button>
            </div>
            <PayrollTable data={payrolls} onEdit={handleEditPayroll} onDelete={handleDeletePayroll} />
          </div>
        )}
        {activeTab === 'loans' && (
          <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Pozajmice</h2>
                <button onClick={handleAddNewLoan} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-sm">Nova pozajmica</button>
            </div>
            <LoansTable data={loans} onEdit={handleEditLoan} onDelete={handleDeleteLoan} />
          </div>
        )}
      </div>

        <PayrollModal isOpen={isPayrollModalOpen} onClose={() => setIsPayrollModalOpen(false)} onSave={handleSavePayroll} initialData={editingPayroll} employees={mockEmployees} />
        <LoanModal isOpen={isLoanModalOpen} onClose={() => setIsLoanModalOpen(false)} onSave={handleSaveLoan} initialData={editingLoan} employees={mockEmployees} />
    </div>
  );
};

export default PayrollPage;

