import React, { useEffect, useState } from "react";
import axios from "axios";
import LoansTable from "../components/loans/LoansTable";
import LoanModal from "../components/loans/LoanModal";

const LoanPage: React.FC = () => {
  const [loans, setLoans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  const fetchLoans = async () => {
    setLoading(true);
    try {
      const response = await axios.get("/api/loan");
      setLoans(response.data);
    } catch (e) {
      console.error("Error fetching loans", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLoans();
  }, []);

  const onEdit = (loan: any) => {
    setSelectedLoan(loan);
    setModalOpen(true);
  };

  const onDelete = async (id: any) => {
    if (window.confirm("Are you sure to delete this loan?")) {
      try {
        await axios.delete(`/api/loan/${id}`);
        fetchLoans();
      } catch (e) {
        console.error("Error deleting loan", e);
      }
    }
  };

  const onSave = async (loan: any) => {
    try {
      if (loan.id) {
        await axios.put(`/api/loan/${loan.id}`, loan);
      } else {
        await axios.post("/api/loan", loan);
      }
      fetchLoans();
      setModalOpen(false);
      setSelectedLoan(null);
    } catch (e) {
      console.error("Error saving loan", e);
    }
  };

  const onClose = () => {
    setModalOpen(false);
    setSelectedLoan(null);
  };

  return (
    <div className="p-4">
      <h1 className="font-semibold text-xl mb-4">Loans</h1>
      <button
        className="mb-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={() => setModalOpen(true)}
      >
        Add Loan
      </button>

      <LoansTable loans={loans} loading={loading} onEdit={onEdit} onDelete={onDelete} />

      {modalOpen && (
        <LoanModal loan={selectedLoan} onSave={onSave} onClose={onClose} />
      )}
    </div>
  );
};

export default LoanPage;
