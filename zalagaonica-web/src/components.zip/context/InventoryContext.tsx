import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Article } from '../types/article';

type WarehouseType = 'main' | 'pledge';

export interface SaleData {
  id: string;
  articleId: string;
  quantity: number;
  saleDate: Date;
  pricePerUnit: number;
  totalPrice: number;
  pledgeId?: string;
  customerName?: string;
  customerId?: string;
}

export interface Pledge {
  id: string;
  articleId: string;
  clientName: string;
  pledgeDate: Date;
  redeemDeadline: Date;
  pledgeValue: number;
  quantity: number;
  redeemed: boolean;
}

interface InventoryContextProps {
  articles: Article[];
  pledges: Pledge[];
  saleRecords: SaleData[];
  addArticle: (article: Article) => void;
  updateArticle: (article: Article) => void;
  createPledge: (pledge: Pledge) => boolean;
  updatePledge: (pledge: Pledge) => boolean;
  redeemPledge: (pledgeId: string) => boolean;
  cancelPledge: (pledgeId: string) => boolean;
  deletePledge: (pledgeId: string) => void;
  sale: (articleId: string, quantity: number, saleData: SaleData) => boolean;
}

const STORAGE_KEY = 'inventory_data_v1';

export const InventoryContext = createContext<InventoryContextProps | undefined>(undefined);

export const InventoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [pledges, setPledges] = useState<Pledge[]>([]);
  const [sales, setSales] = useState<SaleData[]>([]);

  // --- LOAD FROM LOCALSTORAGE ---
  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        setArticles(parsed.articles || []);
        setPledges(parsed.pledges || []);
        setSales(parsed.sales || []);
      } catch (err) {
        console.error('Greška pri učitavanju iz localStorage:', err);
      }
    }
  }, []);

  // --- SAVE TO LOCALSTORAGE ---
  useEffect(() => {
    const data = JSON.stringify({ articles, pledges, sales });
    localStorage.setItem(STORAGE_KEY, data);
  }, [articles, pledges, sales]);

  // --- CRUD OPERACIJE ---
  const addArticle = (article: Article) => {
    setArticles(prev => [...prev, article]);
  };

  const updateArticle = (article: Article) => {
    setArticles(prev => prev.map(a => (a.id === article.id ? article : a)));
  };

  const createPledge = (pledge: Pledge): boolean => {
    const article = articles.find(a => a.id === pledge.articleId && a.warehouse === 'main');
    if (!article || article.stock < pledge.quantity) return false;

    const updatedArticle = { ...article, stock: article.stock - pledge.quantity };
    setArticles(prev => prev.map(a => (a.id === pledge.articleId ? updatedArticle : a)));
    setPledges(prev => [...prev, pledge]);
    return true;
  };

  const updatePledge = (pledge: Pledge): boolean => {
    const exists = pledges.some(p => p.id === pledge.id);
    if (!exists) return false;
    setPledges(prev => prev.map(p => (p.id === pledge.id ? pledge : p)));
    return true;
  };

  const redeemPledge = (pledgeId: string): boolean => {
    const pledge = pledges.find(p => p.id === pledgeId);
    if (!pledge || pledge.redeemed) return false;

    const article = articles.find(a => a.id === pledge.articleId);
    if (!article) return false;

    const updatedArticle = { ...article, stock: article.stock + pledge.quantity };
    setArticles(prev => prev.map(a => (a.id === pledge.articleId ? updatedArticle : a)));

    setPledges(prev => prev.map(p => (p.id === pledgeId ? { ...p, redeemed: true } : p)));
    return true;
  };

  const cancelPledge = (pledgeId: string): boolean => {
    const pledge = pledges.find(p => p.id === pledgeId);
    if (!pledge || pledge.redeemed) return false;

    const article = articles.find(a => a.id === pledge.articleId);
    if (article) {
      const updatedArticle = { ...article, stock: article.stock + pledge.quantity };
      setArticles(prev => prev.map(a => (a.id === pledge.articleId ? updatedArticle : a)));
    }

    setPledges(prev => prev.filter(p => p.id !== pledgeId));
    return true;
  };

  const deletePledge = (pledgeId: string) => {
    setPledges(prev => prev.filter(p => p.id !== pledgeId));
  };

  const sale = (articleId: string, quantity: number, saleData: SaleData): boolean => {
    const article = articles.find(a => a.id === articleId);
    if (!article || article.stock < quantity) return false;

    const updatedArticle = { ...article, stock: article.stock - quantity };
    setArticles(prev => prev.map(a => (a.id === articleId ? updatedArticle : a)));

    const newSale: SaleData = {
      ...saleData,
      id: saleData.id || Date.now().toString(),
      articleId,
      quantity,
      saleDate: saleData.saleDate || new Date(),
      pricePerUnit: saleData.pricePerUnit || article.retailPrice,
      totalPrice:
        saleData.pricePerUnit !== undefined
          ? saleData.pricePerUnit * quantity
          : article.retailPrice * quantity,
    };
    setSales(prev => [...prev, newSale]);
    return true;
  };

  return (
    <InventoryContext.Provider
      value={{
        articles,
        pledges,
        saleRecords: sales,
        addArticle,
        updateArticle,
        createPledge,
        updatePledge,
        redeemPledge,
        cancelPledge,
        deletePledge,
        sale,
      }}
    >
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = (): InventoryContextProps => {
  const context = useContext(InventoryContext);
  if (!context) throw new Error('useInventory must be used within InventoryProvider');
  return context;
};
